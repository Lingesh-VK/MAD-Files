package com.example.calculator

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    // Use lazy initialization to ensure views are found after setContentView
    private val resultTextView by lazy { findViewById<TextView>(R.id.resultTextView) }
    private val expressionTextView by lazy { findViewById<TextView>(R.id.expressionTextView) }

    private var lastNumber: Double = 0.0
    private var currentOperation: String = ""
    private var isNewOperation: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Views are automatically initialized through lazy properties

        // Initialize number buttons
        setupNumberButtons()

        // Setup operation buttons
        setupOperationButtons()

        // Setup special function buttons
        setupFunctionButtons()

        // Setup other buttons
        setupOtherButtons()
    }

    private fun setupNumberButtons() {
        val numberButtons = arrayOf(
            findViewById<Button>(R.id.btn0),
            findViewById<Button>(R.id.btn1),
            findViewById<Button>(R.id.btn2),
            findViewById<Button>(R.id.btn3),
            findViewById<Button>(R.id.btn4),
            findViewById<Button>(R.id.btn5),
            findViewById<Button>(R.id.btn6),
            findViewById<Button>(R.id.btn7),
            findViewById<Button>(R.id.btn8),
            findViewById<Button>(R.id.btn9)
        )

        numberButtons.forEach { button ->
            button.setOnClickListener {
                if (isNewOperation) {
                    resultTextView.text = ""
                    isNewOperation = false
                }

                val numberText = resultTextView.text.toString()
                val buttonText = button.text.toString()

                resultTextView.text = numberText + buttonText
                updateExpressionView()
            }
        }

        // Setup decimal point button
        findViewById<Button>(R.id.btnDecimal).setOnClickListener {
            if (isNewOperation) {
                resultTextView.text = "0."
                isNewOperation = false
            } else if (!resultTextView.text.contains(".")) {
                resultTextView.text = resultTextView.text.toString() + "."
            }
            updateExpressionView()
        }
    }

    private fun setupOperationButtons() {
        // Basic arithmetic operations
        val operationButtons = mapOf(
            R.id.btnAdd to "+",
            R.id.btnSubtract to "-",
            R.id.btnMultiply to "*",
            R.id.btnDivide to "/",
            R.id.btnMod to "%"
        )

        operationButtons.forEach { (id, operator) ->
            findViewById<Button>(id).setOnClickListener {
                if (resultTextView.text.isNotEmpty()) {
                    lastNumber = resultTextView.text.toString().toDouble()
                    currentOperation = operator
                    isNewOperation = true
                    updateExpressionView()
                }
            }
        }

        // Equals button
        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            if (resultTextView.text.isNotEmpty() && currentOperation.isNotEmpty()) {
                val secondNumber = resultTextView.text.toString().toDouble()
                val result = performOperation(lastNumber, secondNumber, currentOperation)

                resultTextView.text = formatResult(result)
                expressionTextView.text = formatResult(lastNumber) + " " + currentOperation + " " + formatResult(secondNumber) + " = " + formatResult(result)

                lastNumber = result
                currentOperation = ""
                isNewOperation = true
            }
        }
    }

    private fun setupFunctionButtons() {
        // Scientific functions
        findViewById<Button>(R.id.btnSin).setOnClickListener { applyFunction("sin") }
        findViewById<Button>(R.id.btnCos).setOnClickListener { applyFunction("cos") }
        findViewById<Button>(R.id.btnTan).setOnClickListener { applyFunction("tan") }
        findViewById<Button>(R.id.btnLog).setOnClickListener { applyFunction("log") }
        findViewById<Button>(R.id.btnSqrt).setOnClickListener { applyFunction("sqrt") }
        findViewById<Button>(R.id.btnPow).setOnClickListener {
            if (resultTextView.text.isNotEmpty()) {
                lastNumber = resultTextView.text.toString().toDouble()
                currentOperation = "^"
                isNewOperation = true
                updateExpressionView()
            }
        }
    }

    private fun setupOtherButtons() {
        // Clear button
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            resultTextView.text = ""
            expressionTextView.text = ""
            lastNumber = 0.0
            currentOperation = ""
            isNewOperation = true
        }

        // Delete button (backspace)
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            val text = resultTextView.text.toString()
            if (text.isNotEmpty()) {
                resultTextView.text = text.substring(0, text.length - 1)
                updateExpressionView()
            }
        }

        // +/- button (change sign)
        findViewById<Button>(R.id.btnNegate).setOnClickListener {
            if (resultTextView.text.isNotEmpty()) {
                val value = resultTextView.text.toString().toDouble() * -1
                resultTextView.text = formatResult(value)
                updateExpressionView()
            }
        }
    }

    private fun applyFunction(function: String) {
        if (resultTextView.text.isNotEmpty()) {
            val value = resultTextView.text.toString().toDouble()
            val result = when (function) {
                "sin" -> sin(Math.toRadians(value))
                "cos" -> cos(Math.toRadians(value))
                "tan" -> tan(Math.toRadians(value))
                "log" -> log10(value)
                "sqrt" -> sqrt(value)
                else -> value
            }

            resultTextView.text = formatResult(result)
            expressionTextView.text = "$function($value) = ${formatResult(result)}"
            lastNumber = result
            isNewOperation = true
        } else {
            Toast.makeText(this, "Enter a number first", Toast.LENGTH_SHORT).show()
        }
    }

    private fun performOperation(first: Double, second: Double, operation: String): Double {
        return when (operation) {
            "+" -> first + second
            "-" -> first - second
            "*" -> first * second
            "/" -> first / second
            "%" -> first % second
            "^" -> first.pow(second)
            else -> second
        }
    }

    private fun formatResult(result: Double): String {
        return if (result == result.toInt().toDouble()) {
            result.toInt().toString()
        } else {
            result.toString()
        }
    }

    private fun updateExpressionView() {
        if (currentOperation.isEmpty()) {
            expressionTextView.text = resultTextView.text
        } else {
            expressionTextView.text = "${formatResult(lastNumber)} $currentOperation ${resultTextView.text}"
        }
    }
}